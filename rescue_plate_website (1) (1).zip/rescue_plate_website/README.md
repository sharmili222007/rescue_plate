# Rescue Plate website starter

## Files
- `index.html` — page structure and editable text
- `style.css` — colors, layout, responsive design, and animation
- `script.js` — intro animation, mobile menu, demo search, and demo login/signup/contact forms

## Run it
1. Download and extract the ZIP.
2. Open the `rescue_plate_website` folder.
3. Double-click `index.html` to open it in Chrome, Edge, or Firefox.
4. To edit comfortably, open the folder in Visual Studio Code and edit the three files.

## Easy customizations
- Change page wording and section content in `index.html`.
- Change the main colors at the top of `style.css` under `:root`.
- Change the intro animation duration in `script.js` (`4300` means 4.3 seconds).
- Replace the Unsplash image URLs in `index.html` with your own image URLs or local image files.

## Important project note
This is an editable front-end prototype. The food cards are clearly marked as example listings. Search filters these sample cards only. Login/signup and contact forms display demo messages; they do not save data or send messages. For a working donation platform, add a backend/database, authentication, food listing CRUD, NGO accounts, and collection status tracking. The design loads Google Fonts and food images from the internet, so those assets require an internet connection.
